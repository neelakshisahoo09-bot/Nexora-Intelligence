const toast = document.getElementById('toast');
const showToast = (message) => {
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2200);
};

const insights = [
  "The strongest opportunity is not the largest signal—it is the signal with enough supporting evidence to act on confidently.",
  "Repeated weak signals can become strategically important when they converge around the same underlying pattern.",
  "A useful decision is one that reduces uncertainty, not simply one that produces more information."
];

let insightIndex = 0;

document.getElementById('insightBtn').addEventListener('click', () => {
  insightIndex = (insightIndex + 1) % insights.length;
  document.getElementById('insightText').textContent = insights[insightIndex];
  showToast('New insight generated.');
});

document.getElementById('analyzeBtn').addEventListener('click', runAnalysis);
document.getElementById('demoBtn').addEventListener('click', runAnalysis);

function runAnalysis() {
  const values = {
    signalCount: Math.floor(12 + Math.random() * 6),
    confidence: Math.floor(84 + Math.random() * 12),
    insightCount: Math.floor(24 + Math.random() * 5),
    decisionCount: String(Math.floor(8 + Math.random() * 3)).padStart(2, '0')
  };
  Object.entries(values).forEach(([id, value]) => {
    document.getElementById(id).textContent = id === 'confidence' ? `${value}%` : value;
  });
  showToast('Analysis complete — workspace refreshed.');
}

document.getElementById('refreshBtn').addEventListener('click', () => {
  const list = document.getElementById('actionList');
  list.style.opacity = '0.45';
  setTimeout(() => {
    list.style.opacity = '1';
    showToast('Priority actions refreshed.');
  }, 350);
});

document.getElementById('scrollBtn').addEventListener('click', () => {
  document.getElementById('workspace-section').scrollIntoView({behavior:'smooth'});
});

document.querySelectorAll('.nav-item').forEach(button => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    button.classList.add('active');
    const view = button.dataset.view;
    const titles = {
      overview: 'Turn information into direction.',
      insights: 'Find the ideas worth acting on.',
      signals: 'Track what is changing.',
      workspace: 'Your intelligence workspace.'
    };
    document.getElementById('page-title').textContent = titles[view];
    showToast(`${view.charAt(0).toUpperCase() + view.slice(1)} view selected.`);
  });
});
